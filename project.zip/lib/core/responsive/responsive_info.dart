import 'package:flutter/material.dart';

import '../tokens/tokens.dart';

/// Immutable responsive state derived from the current viewport.
@immutable
class ResponsiveInfo {
  const ResponsiveInfo({required this.width, required this.height});

  factory ResponsiveInfo.fromContext(BuildContext context) {
    final size = MediaQuery.sizeOf(context);

    return ResponsiveInfo(width: size.width, height: size.height);
  }

  final double width;
  final double height;

  bool get isMobile => width < AppBreakpoints.mobile;

  bool get isTablet {
    return width >= AppBreakpoints.mobile && width < AppBreakpoints.desktop;
  }

  bool get isDesktop => width >= AppBreakpoints.desktop;

  double get pagePadding {
    if (isDesktop) {
      return AppSpacing.xl;
    }

    if (isTablet) {
      return AppSpacing.lg;
    }

    return AppSpacing.md;
  }

  double get contentWidth {
    if (isDesktop) {
      return AppBreakpoints.desktopContentWidth;
    }

    if (isTablet) {
      return AppBreakpoints.tabletContentWidth;
    }

    return width;
  }

  int get columns {
    if (width >= 1600) {
      return 5;
    }

    if (isDesktop) {
      return 4;
    }

    if (isTablet) {
      return 2;
    }

    return 1;
  }
}
