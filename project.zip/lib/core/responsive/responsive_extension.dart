import 'package:flutter/widgets.dart';

import 'responsive_info.dart';

/// Responsive shortcut for contexts that only import core/responsive.
extension ResponsiveBuildContextExtension on BuildContext {
  ResponsiveInfo get responsiveInfo => ResponsiveInfo.fromContext(this);
}
