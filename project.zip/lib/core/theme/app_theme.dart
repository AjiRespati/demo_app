import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app_glass_theme.dart';

/// Material theme entry point for Glass Admin Kit.
abstract final class AppTheme {
  static const Color _lightSeed = Color(0xFF2563EB);
  static const Color _darkSeed = Color(0xFF38BDF8);

  static ThemeData light() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: _lightSeed,
      brightness: Brightness.light,
    );

    return _themeData(
      colorScheme: colorScheme,
      glassTheme: AppGlassTheme.light(),
    );
  }

  static ThemeData dark() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: _darkSeed,
      brightness: Brightness.dark,
    );

    return _themeData(
      colorScheme: colorScheme,
      glassTheme: AppGlassTheme.dark(),
    );
  }

  static ThemeData _themeData({
    required ColorScheme colorScheme,
    required AppGlassTheme glassTheme,
  }) {
    final textTheme = GoogleFonts.interTextTheme().apply(
      bodyColor: colorScheme.onSurface,
      displayColor: colorScheme.onSurface,
    );

    return ThemeData(
      colorScheme: colorScheme,
      textTheme: textTheme,
      useMaterial3: true,
      extensions: <ThemeExtension<dynamic>>[glassTheme],
    );
  }
}
