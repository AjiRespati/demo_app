import 'package:flutter/material.dart';

import '../responsive/responsive.dart';
import '../theme/theme.dart';

/// Common theme accessors for widget code.
extension BuildContextThemeExtensions on BuildContext {
  ColorScheme get colorScheme => Theme.of(this).colorScheme;

  TextTheme get textTheme => Theme.of(this).textTheme;

  AppGlassTheme get glassTheme {
    final extension = Theme.of(this).extension<AppGlassTheme>();
    return extension ?? AppGlassTheme.light();
  }

  ResponsiveInfo get responsive => ResponsiveInfo.fromContext(this);
}
