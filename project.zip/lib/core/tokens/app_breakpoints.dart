/// Responsive breakpoint tokens.
abstract final class AppBreakpoints {
  static const double mobile = 768;
  static const double desktop = 1200;

  static const double tabletContentWidth = 960;
  static const double desktopContentWidth = 1440;
}
